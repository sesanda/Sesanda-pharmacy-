import { useState, useMemo, useRef, useEffect } from "react";

const ADMIN_PASSWORD = "Madu";
const DELIVERY_FEE = 3.50;
const TAX_RATE = 0.08;
const UNIT_OPTIONS = ["Tablet","Capsule","Card","Pack","Vial","Syrup","Cream","Drop"];
const CATEGORY_OPTIONS = ["Pain Relief","Antibiotic","Gastro","Diabetes","Allergy","Cholesterol","Supplements","Other"];

const INITIAL_DRUGS = [
  { id:1, name:"Paracetamol 500mg", category:"Pain Relief", image:"💊", brands:[
    { name:"Panadol", stock:250, expiry:"2027-03-15", barcode:"4012345678901", unitTypes:[{type:"Tablet",qty:1,price:2.50},{type:"Card",qty:10,price:22.00},{type:"Pack",qty:100,price:200.00}]},
    { name:"Calpol", stock:180, expiry:"2027-05-20", barcode:"5000158122205", unitTypes:[{type:"Tablet",qty:1,price:2.20},{type:"Card",qty:10,price:19.50},{type:"Pack",qty:100,price:185.00}]},
  ]},
  { id:2, name:"Amoxicillin 250mg", category:"Antibiotic", image:"💊", brands:[
    { name:"Amoxil", stock:80, expiry:"2026-11-20", barcode:"3400936354016", unitTypes:[{type:"Capsule",qty:1,price:8.75},{type:"Card",qty:8,price:65.00},{type:"Pack",qty:50,price:380.00}]},
    { name:"Flemoxin", stock:60, expiry:"2027-02-10", barcode:"8712345000021", unitTypes:[{type:"Capsule",qty:1,price:9.50},{type:"Card",qty:8,price:72.00},{type:"Pack",qty:50,price:420.00}]},
  ]},
  { id:3, name:"Omeprazole 20mg", category:"Gastro", image:"💊", brands:[
    { name:"Losec", stock:120, expiry:"2027-06-10", barcode:"7312345678903", unitTypes:[{type:"Capsule",qty:1,price:5.50},{type:"Card",qty:14,price:72.00},{type:"Pack",qty:28,price:138.00}]},
  ]},
  { id:4, name:"Metformin 500mg", category:"Diabetes", image:"💊", brands:[
    { name:"Glucophage", stock:200, expiry:"2027-01-25", barcode:"3400936354023", unitTypes:[{type:"Tablet",qty:1,price:3.20},{type:"Card",qty:15,price:44.00},{type:"Pack",qty:60,price:168.00}]},
  ]},
  { id:5, name:"Cetirizine 10mg", category:"Allergy", image:"💊", brands:[
    { name:"Zyrtec", stock:180, expiry:"2027-09-12", barcode:"5099627114841", unitTypes:[{type:"Tablet",qty:1,price:4.00},{type:"Card",qty:10,price:36.00},{type:"Pack",qty:30,price:105.00}]},
  ]},
  { id:6, name:"Vitamin C 1000mg", category:"Supplements", image:"🌿", brands:[
    { name:"Celin", stock:300, expiry:"2028-01-01", barcode:"8901030860453", unitTypes:[{type:"Tablet",qty:1,price:6.50},{type:"Card",qty:10,price:60.00},{type:"Pack",qty:30,price:175.00}]},
  ]},
];

function stockStatus(stock) {
  if (stock===0) return {label:"Out of Stock",color:"#ef4444",bg:"#fef2f2"};
  if (stock<=20) return {label:"Low Stock",color:"#f59e0b",bg:"#fffbeb"};
  return {label:"In Stock",color:"#16a34a",bg:"#f0fdf4"};
}
function expiryColor(exp) {
  const m=(new Date(exp)-new Date())/(1000*60*60*24*30);
  return m<3?"#ef4444":m<6?"#f59e0b":"#64748b";
}
function genId(arr){return arr.length>0?Math.max(...arr.map(d=>d.id))+1:1;}

// ─── SHARED STYLES ────────────────────────────────
const C = {
  app:{fontFamily:"'Inter',sans-serif",minHeight:"100vh",background:"#f0f4f8",color:"#1e293b"},
  header:{background:"linear-gradient(135deg,#0a0a0a,#1a1a1a)",padding:"14px 18px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(0,0,0,.5)"},
  logoText:{color:"#fff",fontWeight:800,fontSize:19},
  logoSub:{color:"#4ade80",fontSize:10},
  cartBtn:{background:"linear-gradient(135deg,#16a34a,#22c55e)",border:"none",borderRadius:10,padding:"7px 14px",cursor:"pointer",display:"flex",alignItems:"center",gap:6,fontWeight:700,color:"#fff",fontSize:13},
  badge:{background:"#ef4444",color:"#fff",borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800},
  tabs:{display:"flex",background:"#fff",borderBottom:"1px solid #e2e8f0",padding:"10px 14px",gap:4},
  tab:a=>({flex:1,padding:"7px 8px",border:"none",borderRadius:8,cursor:"pointer",fontWeight:700,fontSize:12,background:a?"#16a34a":"transparent",color:a?"#fff":"#64748b"}),
  searchRow:{padding:"10px 14px",background:"#fff",borderBottom:"1px solid #e2e8f0"},
  searchInput:{width:"100%",border:"1.5px solid #e2e8f0",borderRadius:10,padding:"9px 14px",fontSize:14,outline:"none",background:"#f8fafc",boxSizing:"border-box"},
  catRow:{display:"flex",gap:6,padding:"8px 14px",overflowX:"auto",background:"#fff",borderBottom:"1px solid #e2e8f0"},
  chip:a=>({padding:"5px 12px",borderRadius:20,border:"1.5px solid",borderColor:a?"#16a34a":"#e2e8f0",background:a?"#16a34a":"#fff",color:a?"#fff":"#64748b",fontSize:11,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}),
  grid:{padding:"10px 14px",display:"flex",flexDirection:"column",gap:10},
  card:{background:"#fff",borderRadius:14,overflow:"hidden",boxShadow:"0 1px 5px rgba(0,0,0,.07)",border:"1px solid #f1f5f9"},
  cardHeader:{padding:"13px 14px",display:"flex",justifyContent:"space-between",alignItems:"flex-start",cursor:"pointer"},
  drugName:{fontWeight:800,fontSize:14,color:"#1e293b",marginBottom:2},
  pill:s=>({display:"inline-block",padding:"2px 9px",borderRadius:20,fontSize:10,fontWeight:800,color:s.color,background:s.bg}),
  panel:{borderTop:"1px solid #f1f5f9",padding:"12px 14px",background:"#fafbff"},
  sLabel:{fontSize:10,fontWeight:800,color:"#94a3b8",textTransform:"uppercase",marginBottom:6},
  brandRow:{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10},
  brandBtn:sel=>({padding:"6px 12px",borderRadius:8,border:"1.5px solid",borderColor:sel?"#16a34a":"#cbd5e1",background:sel?"#f0fdf4":"#fff",color:sel?"#16a34a":"#475569",fontSize:12,fontWeight:700,cursor:"pointer"}),
  unitRow:{display:"flex",gap:6,marginBottom:12,flexWrap:"wrap"},
  unitBtn:sel=>({flex:1,padding:"8px 6px",borderRadius:10,border:"2px solid",borderColor:sel?"#16a34a":"#e2e8f0",background:sel?"#16a34a":"#fff",color:sel?"#fff":"#475569",fontSize:11,fontWeight:700,cursor:"pointer",textAlign:"center"}),
  priceBox:{background:"linear-gradient(135deg,#0a0a0a,#166534)",borderRadius:12,padding:"10px 14px",marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"},
  qtyRow:{display:"flex",alignItems:"center",gap:8},
  qtyBtn:d=>({width:34,height:34,borderRadius:9,border:"2px solid",borderColor:d?"#e2e8f0":"#16a34a",background:d?"#f8fafc":"#16a34a",color:d?"#cbd5e1":"#fff",fontSize:20,fontWeight:700,cursor:d?"not-allowed":"pointer",display:"flex",alignItems:"center",justifyContent:"center"}),
  qtyNum:{fontSize:18,fontWeight:800,minWidth:32,textAlign:"center"},
  totalAmt:{fontSize:16,fontWeight:800,color:"#16a34a",marginLeft:"auto"},
  cartSection:{padding:"12px 14px"},
  cartItem:{background:"#fff",borderRadius:12,padding:14,marginBottom:10,boxShadow:"0 1px 4px rgba(0,0,0,.06)",border:"1px solid #f1f5f9"},
  ciName:{fontWeight:800,fontSize:14,marginBottom:2},
  ciBrand:{fontSize:11,color:"#16a34a",fontWeight:600,marginBottom:8},
  ciGrid:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:8},
  ciField:{background:"#f8fafc",borderRadius:8,padding:"6px 9px"},
  ciLabel:{fontSize:10,color:"#94a3b8",fontWeight:700},
  ciVal:c=>({fontSize:12,fontWeight:800,color:c||"#1e293b"}),
  summaryCard:{background:"linear-gradient(135deg,#0a0a0a,#166534)",borderRadius:14,padding:"14px 16px",margin:"0 0 12px",color:"#fff"},
  sumRow:{display:"flex",justifyContent:"space-between",marginBottom:6,fontSize:13},
  sumTotal:{display:"flex",justifyContent:"space-between",paddingTop:10,borderTop:"1px solid rgba(255,255,255,.3)",fontSize:17,fontWeight:800},
  waBtn:{width:"100%",padding:14,border:"none",borderRadius:12,background:"linear-gradient(135deg,#25d366,#128c7e)",color:"#fff",fontWeight:800,fontSize:15,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:"0 4px 14px rgba(37,211,102,.35)",marginBottom:10},
  inputLabel:{fontSize:11,fontWeight:700,color:"#64748b",marginBottom:4,display:"block"},
  inputField:{width:"100%",border:"1.5px solid #e2e8f0",borderRadius:10,padding:"10px 13px",fontSize:14,outline:"none",background:"#f8fafc",boxSizing:"border-box",marginBottom:10},
  selectField:{width:"100%",border:"1.5px solid #e2e8f0",borderRadius:10,padding:"10px 13px",fontSize:14,outline:"none",background:"#f8fafc",boxSizing:"border-box",marginBottom:10},
  section:{background:"#fff",borderRadius:14,padding:14,marginBottom:12,boxShadow:"0 1px 4px rgba(0,0,0,.06)"},
  secTitle:{fontWeight:800,fontSize:14,color:"#16a34a",marginBottom:12},
  empty:{textAlign:"center",padding:"48px 24px",color:"#94a3b8"},
  greenBtn:{background:"linear-gradient(135deg,#16a34a,#22c55e)",color:"#fff",border:"none",borderRadius:10,padding:"11px 18px",fontWeight:800,fontSize:13,cursor:"pointer"},
  redBtn:{background:"#fee2e2",color:"#ef4444",border:"none",borderRadius:8,padding:"6px 12px",fontWeight:700,fontSize:12,cursor:"pointer"},
  grayBtn:{background:"#f1f5f9",color:"#64748b",border:"none",borderRadius:8,padding:"8px 14px",fontWeight:700,fontSize:12,cursor:"pointer"},
  editBtn:{background:"#f0fdf4",color:"#16a34a",border:"1.5px solid #16a34a",borderRadius:8,padding:"6px 12px",fontWeight:700,fontSize:12,cursor:"pointer"},
  adminCard:{background:"#fff",borderRadius:12,padding:14,marginBottom:10,boxShadow:"0 1px 4px rgba(0,0,0,.06)",border:"1px solid #f1f5f9"},
  stockInput:{width:80,border:"1.5px solid #e2e8f0",borderRadius:8,padding:"5px 8px",fontSize:13,fontWeight:700,textAlign:"center",outline:"none"},
  scanBtn:{background:"linear-gradient(135deg,#0a0a0a,#1a1a1a)",color:"#4ade80",border:"1.5px solid #4ade80",borderRadius:8,padding:"7px 12px",fontWeight:700,fontSize:12,cursor:"pointer",display:"flex",alignItems:"center",gap:5},
};

// ─── SCANNER MODAL ────────────────────────────────
function ScannerModal({ drugs, onFound, onClose }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const scanningRef = useRef(false);
  const [mode, setMode] = useState("init");
  const [foundInfo, setFoundInfo] = useState(null);
  const [manualInput, setManualInput] = useState("");
  const [manualError, setManualError] = useState("");
  const [camError, setCamError] = useState("");

  useEffect(() => () => stopCamera(), []);

  function stopCamera() {
    scanningRef.current = false;
    if (streamRef.current) { streamRef.current.getTracks().forEach(t=>t.stop()); streamRef.current=null; }
  }

  function searchBrand(text) {
    if (!text) return null;
    const t = text.trim().toLowerCase();
    for (const drug of drugs) {
      for (let bi=0; bi<drug.brands.length; bi++) {
        const b = drug.brands[bi];
        if (b.barcode && text.trim()===b.barcode.trim()) return {drug,brandIdx:bi,matchType:"barcode"};
        if (t===b.name.toLowerCase()) return {drug,brandIdx:bi,matchType:"name"};
        if (b.name.toLowerCase().includes(t) && t.length>=3) return {drug,brandIdx:bi,matchType:"name"};
      }
    }
    return null;
  }

  async function tryCamera() {
    setMode("camera"); setCamError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}});
      streamRef.current = stream;
      if (videoRef.current) { videoRef.current.srcObject=stream; await videoRef.current.play(); }
      scanningRef.current = true;
      if (!window.ZXing) {
        await new Promise((res,rej)=>{
          const s=document.createElement("script");
          s.src="https://cdn.jsdelivr.net/npm/@zxing/library@0.20.0/umd/index.min.js";
          s.onload=res; s.onerror=rej; document.head.appendChild(s);
        });
      }
      doScan();
    } catch(e) {
      setCamError(e.name==="NotAllowedError"
        ? "Camera permission deny wunata.\n\nBrowser address bar eke 🔒 icon → Camera → Allow → Reload karanna."
        : "Camera error: "+e.message);
    }
  }

  async function doScan() {
    if (!scanningRef.current) return;
    const v=videoRef.current, c=canvasRef.current;
    if (!v||!c||v.readyState<2) { setTimeout(doScan,300); return; }
    c.width=v.videoWidth; c.height=v.videoHeight;
    c.getContext("2d").drawImage(v,0,0);
    if (window.ZXing) {
      try {
        const r=new window.ZXing.MultiFormatReader();
        const res=r.decode(new window.ZXing.BinaryBitmap(new window.ZXing.HybridBinarizer(new window.ZXing.HTMLCanvasElementLuminanceSource(c))));
        if (res) { const f=searchBrand(res.getText()); if(f){stopCamera();setFoundInfo({...f,scanned:res.getText()});setMode("found");return;} }
      } catch(_){}
    }
    if (scanningRef.current) setTimeout(doScan,600);
  }

  function handleManualSearch() {
    setManualError("");
    const f=searchBrand(manualInput);
    if (f) { setFoundInfo({...f,scanned:manualInput}); setMode("found"); }
    else setManualError("Match wunana brand ekak naha. Admin panel eke brand name check karanna.");
  }

  function handleConfirm() {
    if (foundInfo) { onFound(foundInfo.drug.id,foundInfo.brandIdx); onClose(); }
  }

  const OV={position:"fixed",inset:0,zIndex:999,background:"#0a0a0a",display:"flex",flexDirection:"column"};
  const TB={background:"#111",padding:"12px 16px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid #222"};
  const CB={background:"#222",border:"1px solid #333",color:"#fff",borderRadius:8,padding:"6px 14px",cursor:"pointer",fontWeight:700,fontSize:13};
  const GB=bg=>({width:"100%",padding:14,border:"none",borderRadius:12,background:bg,color:"#fff",fontWeight:800,fontSize:15,cursor:"pointer",marginBottom:10});

  if (mode==="init") return (
    <div style={OV}>
      <div style={TB}><span style={{color:"#4ade80",fontWeight:800,fontSize:15}}>🔍 Brand Search</span><button style={CB} onClick={onClose}>✕</button></div>
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,gap:12}}>
        <div style={{fontSize:52}}>🔍</div>
        <div style={{color:"#fff",fontWeight:800,fontSize:18,textAlign:"center"}}>Brand search karanne kohomada?</div>
        <div style={{color:"#64748b",fontSize:13,textAlign:"center",marginBottom:8}}>Camera barcode scan, nathnam manually type</div>
        <button style={GB("linear-gradient(135deg,#16a34a,#22c55e)")} onClick={tryCamera}>📷 Camera eken Scan</button>
        <button style={GB("linear-gradient(135deg,#1a1a1a,#2a2a2a)")} onClick={()=>setMode("manual")}>⌨️ Manually Type karanna</button>
      </div>
    </div>
  );

  if (mode==="camera") return (
    <div style={OV}>
      <div style={TB}><span style={{color:"#4ade80",fontWeight:800,fontSize:15}}>📷 Barcode Scan</span><button style={CB} onClick={()=>{stopCamera();onClose();}}>✕</button></div>
      <div style={{flex:1,position:"relative",overflow:"hidden"}}>
        <video ref={videoRef} style={{width:"100%",height:"100%",objectFit:"cover"}} muted playsInline />
        <canvas ref={canvasRef} style={{display:"none"}} />
        {!camError && (
          <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",pointerEvents:"none"}}>
            <div style={{width:250,height:150,position:"relative"}}>
              {[0,1,2,3].map(i=>{const iT=i<2,iL=i%2===0;return <div key={i} style={{position:"absolute",width:36,height:36,top:iT?0:"auto",bottom:iT?"auto":0,left:iL?0:"auto",right:iL?"auto":0,borderTop:iT?"3px solid #4ade80":"none",borderBottom:iT?"none":"3px solid #4ade80",borderLeft:iL?"3px solid #4ade80":"none",borderRight:iL?"none":"3px solid #4ade80"}}/> ;})}
              <div style={{position:"absolute",left:0,right:0,height:2,background:"linear-gradient(90deg,transparent,#4ade80,transparent)",animation:"scanline 2s linear infinite",top:"50%"}}/>
            </div>
            <div style={{color:"#4ade80",fontWeight:700,fontSize:13,marginTop:16,background:"rgba(0,0,0,.7)",padding:"6px 18px",borderRadius:20}}>Barcode eka frame eke danna 📦</div>
          </div>
        )}
        {camError && (
          <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:28,gap:14,background:"rgba(0,0,0,.92)"}}>
            <div style={{fontSize:44}}>📵</div>
            <div style={{color:"#ef4444",fontWeight:700,fontSize:14,textAlign:"center",whiteSpace:"pre-line",lineHeight:1.7}}>{camError}</div>
            <button style={GB("linear-gradient(135deg,#16a34a,#22c55e)")} onClick={()=>{setCamError("");tryCamera();}}>🔄 Again Try</button>
            <button style={{...GB("linear-gradient(135deg,#1a1a1a,#2a2a2a)"),marginBottom:0}} onClick={()=>setMode("manual")}>⌨️ Manual Entry</button>
          </div>
        )}
      </div>
      <div style={{background:"#111",padding:"10px 16px",display:"flex",gap:8}}>
        <button style={{flex:1,padding:11,border:"none",borderRadius:10,background:"#1a1a1a",color:"#fff",fontWeight:700,fontSize:12,cursor:"pointer"}} onClick={()=>{stopCamera();setMode("manual");}}>⌨️ Manual</button>
        <button style={{flex:1,padding:11,border:"none",borderRadius:10,background:"#1a1a1a",color:"#fff",fontWeight:700,fontSize:12,cursor:"pointer"}} onClick={()=>{stopCamera();setMode("init");}}>← Back</button>
      </div>
      <style>{`@keyframes scanline{0%{top:10%}50%{top:90%}100%{top:10%}}`}</style>
    </div>
  );

  if (mode==="manual") return (
    <div style={OV}>
      <div style={TB}><span style={{color:"#4ade80",fontWeight:800,fontSize:15}}>⌨️ Manual Search</span><button style={CB} onClick={onClose}>✕</button></div>
      <div style={{flex:1,padding:20,display:"flex",flexDirection:"column",gap:12,overflowY:"auto"}}>
        <div style={{fontSize:40,textAlign:"center"}}>🔍</div>
        <div style={{color:"#fff",fontWeight:800,fontSize:16,textAlign:"center"}}>Brand name හෝ Barcode type karanna</div>
        <div style={{background:"#111",borderRadius:12,padding:12,maxHeight:200,overflowY:"auto"}}>
          <div style={{color:"#64748b",fontSize:10,fontWeight:700,marginBottom:8}}>AVAILABLE BRANDS</div>
          {drugs.flatMap(d=>d.brands.map(b=>(
            <div key={b.name+d.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:"1px solid #1a1a1a"}}>
              <div><span style={{color:"#fff",fontSize:13,fontWeight:700}}>{b.name}</span><span style={{color:"#555",fontSize:11,marginLeft:8}}>{d.name}</span></div>
              <button style={{background:"#16a34a",border:"none",color:"#fff",borderRadius:6,padding:"4px 12px",fontSize:11,fontWeight:700,cursor:"pointer"}} onClick={()=>{setManualInput(b.name);setManualError("");}}>Use</button>
            </div>
          )))}
        </div>
        <input style={{background:"#1a1a1a",border:"2px solid #4ade80",borderRadius:12,padding:"14px 16px",fontSize:16,color:"#fff",outline:"none",boxSizing:"border-box"}}
          placeholder="e.g. Panadol or barcode number" value={manualInput}
          onChange={e=>{setManualInput(e.target.value);setManualError("");}}
          onKeyDown={e=>e.key==="Enter"&&handleManualSearch()} autoFocus />
        {manualError && <div style={{color:"#ef4444",fontSize:12,fontWeight:700}}>❌ {manualError}</div>}
        <button style={GB("linear-gradient(135deg,#16a34a,#22c55e)")} onClick={handleManualSearch}>🔍 Search</button>
        <button style={{...GB("linear-gradient(135deg,#1a1a1a,#2a2a2a)"),marginBottom:0}} onClick={()=>setMode("init")}>← Back</button>
      </div>
    </div>
  );

  if (mode==="found" && foundInfo) return (
    <div style={OV}>
      <div style={TB}><span style={{color:"#4ade80",fontWeight:800,fontSize:15}}>✅ Brand Found!</span><button style={CB} onClick={onClose}>✕</button></div>
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,gap:14}}>
        <div style={{fontSize:56}}>✅</div>
        <div style={{color:"#4ade80",fontWeight:800,fontSize:20}}>Brand Found!</div>
        <div style={{background:"#1a1a1a",borderRadius:16,padding:20,width:"100%",maxWidth:300}}>
          <div style={{color:"#555",fontSize:10,fontWeight:700,marginBottom:4}}>MEDICINE</div>
          <div style={{color:"#fff",fontWeight:800,fontSize:16,marginBottom:12}}>{foundInfo.drug.name}</div>
          <div style={{color:"#555",fontSize:10,fontWeight:700,marginBottom:4}}>BRAND</div>
          <div style={{color:"#4ade80",fontWeight:800,fontSize:26,marginBottom:8}}>{foundInfo.drug.brands[foundInfo.brandIdx].name}</div>
          <div style={{color:"#444",fontSize:11}}>{foundInfo.matchType==="barcode"?"🔢 Barcode":"📝 Name"}: {foundInfo.scanned?.substring(0,30)}</div>
        </div>
        <button style={GB("linear-gradient(135deg,#16a34a,#22c55e)")} onClick={handleConfirm}>✅ Select karala Continue</button>
        <button style={{...GB("linear-gradient(135deg,#1a1a1a,#2a2a2a)"),marginBottom:0}} onClick={()=>{setFoundInfo(null);setManualInput("");setMode("manual");}}>🔄 Again Search</button>
      </div>
    </div>
  );
  return null;
}

// ─── DRUG CARD (top-level component) ─────────────
function DrugCard({ drug, order, openCard, setOpenCard, updateLine, removeItem, openScanner }) {
  const line = order[drug.id] || {brandIdx:0,unitTypeIdx:0,qty:0};
  const isOpen = openCard === drug.id;
  const brand = drug.brands[line.brandIdx] || drug.brands[0];
  if (!brand) return null;
  const ut = brand.unitTypes[line.unitTypeIdx] || brand.unitTypes[0];
  const ss = stockStatus(brand.stock);
  const outOfStock = brand.stock === 0;

  function changeQty(delta) {
    const max = Math.floor(brand.stock/ut.qty);
    const nq = Math.max(0, Math.min(line.qty+delta, max));
    if (nq===0) removeItem(drug.id);
    else updateLine(drug.id,{...line,qty:nq});
  }

  return (
    <div style={C.card}>
      <div style={C.cardHeader} onClick={()=>setOpenCard(isOpen?null:drug.id)}>
        <div>
          <div style={C.drugName}>{drug.image} {drug.name}</div>
          <div style={{fontSize:11,color:"#64748b"}}>{drug.category}</div>
          <div style={{marginTop:6,display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
            <span style={C.pill(ss)}>{ss.label}</span>
            {line.qty>0 && <span style={{fontSize:11,fontWeight:800,color:"#16a34a",background:"#f0fdf4",padding:"2px 8px",borderRadius:20}}>✓ {line.qty}× {brand.unitTypes[line.unitTypeIdx]?.type}</span>}
          </div>
        </div>
        <div style={{textAlign:"right"}}>
          <div style={{fontSize:10,color:"#94a3b8",fontWeight:600,marginBottom:2}}>From</div>
          <div style={{fontWeight:800,fontSize:16,color:"#16a34a"}}>Rs. {Math.min(...drug.brands.flatMap(b=>b.unitTypes.map(u=>u.price))).toFixed(2)}</div>
          <div style={{fontSize:18,color:isOpen?"#16a34a":"#94a3b8",marginTop:4}}>{isOpen?"▲":"▼"}</div>
        </div>
      </div>

      {isOpen && (
        <div style={C.panel}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
            <div style={C.sLabel}>🏷️ Brand Select karanna</div>
            <button style={C.scanBtn} onClick={()=>openScanner(drug.id)}>📷 Scan</button>
          </div>
          <div style={C.brandRow}>
            {drug.brands.map((b,i)=>(
              <button key={i} style={C.brandBtn(line.brandIdx===i)} onClick={()=>updateLine(drug.id,{brandIdx:i,unitTypeIdx:0,qty:0})}>
                {b.name} <span style={{fontSize:9,color:stockStatus(b.stock).color}}>● {stockStatus(b.stock).label}</span>
              </button>
            ))}
          </div>
          <div style={{display:"flex",gap:10,marginBottom:10,fontSize:11}}>
            <div style={{background:"#f0fdf4",borderRadius:8,padding:"5px 10px"}}><span style={{color:"#94a3b8",fontWeight:600}}>Stock: </span><span style={{color:"#16a34a",fontWeight:800}}>{brand.stock}</span></div>
            <div style={{background:"#f8fafc",borderRadius:8,padding:"5px 10px"}}><span style={{color:"#94a3b8",fontWeight:600}}>Exp: </span><span style={{color:expiryColor(brand.expiry),fontWeight:800}}>{brand.expiry}</span></div>
          </div>
          <div style={C.sLabel}>📦 Unit Type</div>
          <div style={C.unitRow}>
            {brand.unitTypes.map((u,i)=>(
              <button key={i} style={C.unitBtn(line.unitTypeIdx===i)} onClick={()=>updateLine(drug.id,{...line,unitTypeIdx:i,qty:0})}>
                <div>{u.type==="Card"?"📋":u.type==="Pack"?"📦":u.type==="Vial"?"🔬":"💊"}</div>
                <div style={{marginTop:2}}>{u.type}</div>
                <div style={{fontSize:10,opacity:0.8}}>{u.qty} units</div>
                <div style={{fontWeight:800,marginTop:2}}>Rs.{u.price}</div>
              </button>
            ))}
          </div>
          {ut && !outOfStock && (
            <div style={C.priceBox}>
              <div>
                <div style={{color:"rgba(255,255,255,.7)",fontSize:10}}>Per {ut.type}</div>
                <div style={{color:"#fff",fontSize:18,fontWeight:800}}>Rs. {ut.price.toFixed(2)}</div>
                <div style={{color:"rgba(255,255,255,.6)",fontSize:10}}>{ut.qty} unit{ut.qty>1?"s":""} inside</div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{color:"rgba(255,255,255,.7)",fontSize:10}}>Per Unit</div>
                <div style={{color:"#4ade80",fontSize:13,fontWeight:800}}>Rs. {(ut.price/ut.qty).toFixed(2)}</div>
              </div>
            </div>
          )}
          {outOfStock
            ? <div style={{textAlign:"center",color:"#ef4444",fontWeight:700,fontSize:13,padding:8}}>❌ Out of Stock</div>
            : <div style={C.qtyRow}>
                <button style={C.qtyBtn(line.qty===0)} onClick={()=>changeQty(-1)}>−</button>
                <span style={C.qtyNum}>{line.qty}</span>
                <button style={C.qtyBtn(line.qty>=Math.floor(brand.stock/ut.qty))} onClick={()=>changeQty(1)}>+</button>
                {line.qty>0 && <span style={C.totalAmt}>= Rs. {(ut.price*line.qty).toFixed(2)}</span>}
              </div>
          }
        </div>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────
export default function PharmacyApp() {
  const [drugs, setDrugs] = useState(INITIAL_DRUGS);
  const [order, setOrder] = useState({});
  const [openCard, setOpenCard] = useState(null);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [view, setView] = useState("shop");
  const [adminAuth, setAdminAuth] = useState(false);
  const [adminPw, setAdminPw] = useState("");
  const [pwError, setPwError] = useState(false);
  const [adminView, setAdminView] = useState("list");
  const [editDrugId, setEditDrugId] = useState(null);
  const [editBrandIdx, setEditBrandIdx] = useState(null);
  const [newDrug, setNewDrug] = useState({name:"",category:"Pain Relief",image:"💊"});
  const [newBrand, setNewBrand] = useState({name:"",stock:"",expiry:"",barcode:"",unitTypes:[{type:"Tablet",qty:1,price:""}]});
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [showScanner, setShowScanner] = useState(false);
  const [scanTarget, setScanTarget] = useState(null);

  const categories = useMemo(()=>["All",...new Set(drugs.map(d=>d.category))],[drugs]);
  const filtered = useMemo(()=>drugs.filter(d=>d.name.toLowerCase().includes(search.toLowerCase())&&(category==="All"||d.category===category)),[drugs,search,category]);

  function updateLine(drugId, patch) { setOrder(prev=>({...prev,[drugId]:{...(prev[drugId]||{brandIdx:0,unitTypeIdx:0,qty:0}),...patch}})); }
  function removeItem(drugId) { setOrder(prev=>{const n={...prev};delete n[drugId];return n;}); }
  function linePrice(drug,line) {
    const b=drug.brands[line.brandIdx]; if(!b) return 0;
    const u=b.unitTypes[line.unitTypeIdx]; if(!u) return 0;
    return u.price*line.qty;
  }

  const cartDrugs = drugs.filter(d=>order[d.id]?.qty>0);
  const cartCount = cartDrugs.length;
  const subtotal = cartDrugs.reduce((s,d)=>s+linePrice(d,order[d.id]),0);
  const tax = subtotal*TAX_RATE;
  const total = subtotal+tax+DELIVERY_FEE;

  function buildWA() {
    return encodeURIComponent([
      `🏥 *Sesanda Pharmacy Order*`,`━━━━━━━━━━━━━━━━━━━━`,
      `👤 *Customer:* ${customerName}`,`📞 *Phone:* ${customerPhone}`,`📍 *Address:* ${deliveryAddress}`,``,`🛒 *Order Details:*`,
      ...cartDrugs.map(drug=>{const l=order[drug.id];const b=drug.brands[l.brandIdx];const u=b.unitTypes[l.unitTypeIdx];return `• *${drug.name}* (${b.name})\n  ${l.qty}× ${u.type} | Rs.${u.price.toFixed(2)}\n  Total: Rs.${(u.price*l.qty).toFixed(2)} | Exp: ${b.expiry}`;}),
      ``,`━━━━━━━━━━━━━━━━━━━━`,
      `💰 Subtotal: Rs. ${subtotal.toFixed(2)}`,`🚚 Delivery: Rs. ${DELIVERY_FEE.toFixed(2)}`,`📊 Tax (8%): Rs. ${tax.toFixed(2)}`,
      `✅ *TOTAL: Rs. ${total.toFixed(2)}*`,
      `📅 ${new Date().toLocaleDateString("en-GB")} ⏰ ${new Date().toLocaleTimeString()}`,
      `Thank you for choosing Sesanda Pharmacy! 💊`,
    ].join("\n"));
  }

  function openScanner(drugId) { setScanTarget(drugId); setShowScanner(true); }
  function handleScanFound(drugId,brandIdx) {
    const tgt=scanTarget||drugId;
    updateLine(tgt,{brandIdx,unitTypeIdx:0,qty:0});
    setOpenCard(tgt); setScanTarget(null);
  }

  // Admin
  function adminLogin() { if(adminPw===ADMIN_PASSWORD){setAdminAuth(true);setPwError(false);setView("admin");}else setPwError(true); }
  function saveDrug() { if(!newDrug.name.trim()) return; setDrugs(p=>[...p,{id:genId(p),...newDrug,brands:[]}]); setNewDrug({name:"",category:"Pain Relief",image:"💊"}); setAdminView("list"); }
  function deleteDrug(id) { if(window.confirm("Delete this medicine?")){ setDrugs(p=>p.filter(d=>d.id!==id)); setOrder(p=>{const n={...p};delete n[id];return n;}); } }
  function saveBrand() {
    if(!newBrand.name.trim()||!newBrand.stock||!newBrand.expiry) return;
    const vuts=newBrand.unitTypes.filter(u=>u.price); if(!vuts.length) return;
    setDrugs(p=>p.map(d=>{
      if(d.id!==editDrugId) return d;
      const brand={name:newBrand.name,stock:parseInt(newBrand.stock),expiry:newBrand.expiry,barcode:newBrand.barcode||"",unitTypes:vuts.map(u=>({...u,qty:parseInt(u.qty),price:parseFloat(u.price)}))};
      if(editBrandIdx!==null){const b=[...d.brands];b[editBrandIdx]=brand;return{...d,brands:b};}
      return{...d,brands:[...d.brands,brand]};
    }));
    setNewBrand({name:"",stock:"",expiry:"",barcode:"",unitTypes:[{type:"Tablet",qty:1,price:""}]}); setEditBrandIdx(null); setAdminView("editDrug");
  }
  function deleteBrand(did,bi){setDrugs(p=>p.map(d=>d.id!==did?d:{...d,brands:d.brands.filter((_,i)=>i!==bi)}));}
  function updateStock(did,bi,v){setDrugs(p=>p.map(d=>d.id!==did?d:{...d,brands:d.brands.map((b,i)=>i===bi?{...b,stock:parseInt(v)||0}:b)}));}
  function addUnitType(){setNewBrand(p=>({...p,unitTypes:[...p.unitTypes,{type:"Card",qty:10,price:""}]}));}
  function removeUnitType(i){setNewBrand(p=>({...p,unitTypes:p.unitTypes.filter((_,idx)=>idx!==i)}));}
  function updateUT(i,f,v){setNewBrand(p=>({...p,unitTypes:p.unitTypes.map((u,idx)=>idx===i?{...u,[f]:v}:u)}));}
  function openEditBrand(did,bi){const d=drugs.find(x=>x.id===did);const b=d.brands[bi];setEditDrugId(did);setEditBrandIdx(bi);setNewBrand({name:b.name,stock:b.stock.toString(),expiry:b.expiry,barcode:b.barcode||"",unitTypes:b.unitTypes.map(u=>({...u,price:u.price.toString(),qty:u.qty.toString()}))});setAdminView("editBrand");}

  const editDrug = drugs.find(d=>d.id===editDrugId);

  return (
    <div style={C.app}>
      {showScanner && <ScannerModal drugs={drugs} onFound={handleScanFound} onClose={()=>{setShowScanner(false);setScanTarget(null);}} />}

      {/* HEADER */}
      <div style={C.header}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:26}}>⚕️</span>
          <div><div style={C.logoText}>Sesanda</div><div style={C.logoSub}>Pharmacy</div></div>
        </div>
        <div style={{display:"flex",gap:8}}>
          <button style={{...C.scanBtn,borderRadius:10,padding:"7px 12px"}} onClick={()=>{setScanTarget(null);setShowScanner(true);}}>📷 Scan</button>
          <button style={C.cartBtn} onClick={()=>setView("cart")}>🛒 {cartCount>0&&<span style={C.badge}>{cartCount}</span>} Cart</button>
        </div>
      </div>

      {/* TABS */}
      <div style={C.tabs}>
        <button style={C.tab(view==="shop")} onClick={()=>setView("shop")}>🏪 Shop</button>
        <button style={C.tab(view==="cart")} onClick={()=>setView("cart")}>🛒 Cart ({cartCount})</button>
        <button style={C.tab(view==="summary")} onClick={()=>setView("summary")}>📋 Order</button>
        <button style={C.tab(view==="admin")} onClick={()=>{if(adminAuth){setView("admin");setAdminView("list");}else setView("admin");}}>⚙️ Admin</button>
      </div>

      {/* SHOP */}
      {view==="shop" && <>
        <div style={C.searchRow}><input style={C.searchInput} placeholder="🔍 Search medicine..." value={search} onChange={e=>setSearch(e.target.value)} /></div>
        <div style={C.catRow}>{categories.map(cat=><button key={cat} style={C.chip(category===cat)} onClick={()=>setCategory(cat)}>{cat}</button>)}</div>
        <div style={C.grid}>
          {filtered.map(drug=><DrugCard key={drug.id} drug={drug} order={order} openCard={openCard} setOpenCard={setOpenCard} updateLine={updateLine} removeItem={removeItem} openScanner={openScanner} />)}
          {filtered.length===0 && <div style={C.empty}><div style={{fontSize:36}}>🔍</div><div>No medicines found</div></div>}
        </div>
      </>}

      {/* CART */}
      {view==="cart" && <>
        {cartDrugs.length===0
          ? <div style={C.empty}><div style={{fontSize:44,marginBottom:10}}>🛒</div><div style={{fontWeight:700,fontSize:15,marginBottom:6}}>Cart is empty</div><button style={{...C.waBtn,maxWidth:180,margin:"16px auto 0",fontSize:13}} onClick={()=>setView("shop")}>🏪 Go to Shop</button></div>
          : <div style={C.cartSection}>
              {cartDrugs.map(drug=>{const l=order[drug.id];const b=drug.brands[l.brandIdx];const u=b.unitTypes[l.unitTypeIdx];const lp=linePrice(drug,l);return(
                <div key={drug.id} style={C.cartItem}>
                  <div style={C.ciName}>{drug.image} {drug.name}</div>
                  <div style={C.ciBrand}>🏷️ {b.name}</div>
                  <div style={C.ciGrid}>
                    <div style={C.ciField}><div style={C.ciLabel}>Unit Type</div><div style={C.ciVal()}>{u.type} ({u.qty} units)</div></div>
                    <div style={C.ciField}><div style={C.ciLabel}>Quantity</div><div style={C.ciVal()}>{l.qty} {u.type}{l.qty>1?"s":""}</div></div>
                    <div style={C.ciField}><div style={C.ciLabel}>Unit Price</div><div style={C.ciVal()}>Rs. {u.price.toFixed(2)}</div></div>
                    <div style={{...C.ciField,background:"#f0fdf4"}}><div style={C.ciLabel}>Line Total</div><div style={C.ciVal("#16a34a")}>Rs. {lp.toFixed(2)}</div></div>
                    <div style={C.ciField}><div style={C.ciLabel}>Expiry</div><div style={{...C.ciVal(expiryColor(b.expiry)),fontSize:11}}>{b.expiry}</div></div>
                    <div style={C.ciField}><div style={C.ciLabel}>Stock Left</div><div style={C.ciVal()}>{b.stock}</div></div>
                  </div>
                  <button style={{fontSize:11,color:"#ef4444",background:"none",border:"none",cursor:"pointer",fontWeight:700,padding:0}} onClick={()=>removeItem(drug.id)}>🗑 Remove</button>
                </div>
              );})}
              <div style={C.summaryCard}>
                <div style={{fontWeight:800,fontSize:13,marginBottom:10,opacity:0.8}}>Order Summary</div>
                <div style={C.sumRow}><span>Subtotal ({cartCount} items)</span><span>Rs. {subtotal.toFixed(2)}</span></div>
                <div style={C.sumRow}><span>🚚 Delivery</span><span>Rs. {DELIVERY_FEE.toFixed(2)}</span></div>
                <div style={C.sumRow}><span>📊 Tax (8%)</span><span>Rs. {tax.toFixed(2)}</span></div>
                <div style={C.sumTotal}><span>Total</span><span>Rs. {total.toFixed(2)}</span></div>
              </div>
              <button style={C.waBtn} onClick={()=>setView("summary")}>📋 Proceed to Order Details</button>
            </div>
        }
      </>}

      {/* ORDER SUMMARY */}
      {view==="summary" && (
        <div style={{padding:14}}>
          <div style={C.section}>
            <div style={C.secTitle}>👤 Customer Details</div>
            <label style={C.inputLabel}>Full Name</label>
            <input style={C.inputField} placeholder="Enter your name" value={customerName} onChange={e=>setCustomerName(e.target.value)} />
            <label style={C.inputLabel}>Phone Number</label>
            <input style={C.inputField} placeholder="+94 7X XXX XXXX" value={customerPhone} onChange={e=>setCustomerPhone(e.target.value)} />
            <label style={C.inputLabel}>Delivery Address</label>
            <input style={C.inputField} placeholder="No. Street, City" value={deliveryAddress} onChange={e=>setDeliveryAddress(e.target.value)} />
          </div>
          <div style={C.section}>
            <div style={C.secTitle}>💊 Order Items</div>
            {cartDrugs.length===0?<div style={{color:"#94a3b8",textAlign:"center",padding:16}}>No items</div>
              :cartDrugs.map(drug=>{const l=order[drug.id];const b=drug.brands[l.brandIdx];const u=b.unitTypes[l.unitTypeIdx];return(
                <div key={drug.id} style={{borderBottom:"1px solid #f1f5f9",paddingBottom:10,marginBottom:10}}>
                  <div style={{fontWeight:800,fontSize:13,marginBottom:4}}>{drug.name} — <span style={{color:"#16a34a"}}>{b.name}</span></div>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6}}>
                    <div style={C.ciField}><div style={C.ciLabel}>Type × Qty</div><div style={C.ciVal()}>{l.qty}× {u.type}</div></div>
                    <div style={C.ciField}><div style={C.ciLabel}>Unit Price</div><div style={C.ciVal()}>Rs. {u.price.toFixed(2)}</div></div>
                    <div style={{...C.ciField,background:"#f0fdf4"}}><div style={C.ciLabel}>Total</div><div style={C.ciVal("#16a34a")}>Rs. {linePrice(drug,l).toFixed(2)}</div></div>
                  </div>
                </div>
              );})}
          </div>
          <div style={C.summaryCard}>
            <div style={{fontWeight:800,fontSize:13,marginBottom:10,opacity:0.8}}>💰 Price Breakdown</div>
            <div style={C.sumRow}><span>Subtotal</span><span>Rs. {subtotal.toFixed(2)}</span></div>
            <div style={C.sumRow}><span>🚚 Delivery</span><span>Rs. {DELIVERY_FEE.toFixed(2)}</span></div>
            <div style={C.sumRow}><span>📊 Tax (8%)</span><span>Rs. {tax.toFixed(2)}</span></div>
            <div style={C.sumTotal}><span>TOTAL</span><span>Rs. {total.toFixed(2)}</span></div>
          </div>
          <button style={{...C.waBtn,opacity:(cartDrugs.length===0||!customerName||!customerPhone)?0.5:1}}
            onClick={()=>{if(cartDrugs.length>0&&customerName&&customerPhone)window.open(`https://wa.me/?text=${buildWA()}`,"_blank");}}>
            <span style={{fontSize:20}}>📲</span> Share Order via WhatsApp
          </button>
          {(!customerName||!customerPhone)&&<div style={{textAlign:"center",fontSize:11,color:"#94a3b8"}}>⚠️ Name & phone required</div>}
        </div>
      )}

      {/* ADMIN */}
      {view==="admin" && !adminAuth && (
        <div style={{padding:24,maxWidth:340,margin:"40px auto"}}>
          <div style={{...C.section,textAlign:"center"}}>
            <div style={{fontSize:48,marginBottom:12}}>🔐</div>
            <div style={{fontWeight:800,fontSize:18,marginBottom:4}}>Admin Panel</div>
            <div style={{fontSize:12,color:"#64748b",marginBottom:20}}>Sesanda Pharmacy</div>
            <label style={C.inputLabel}>Admin Password</label>
            <input style={{...C.inputField,textAlign:"center",letterSpacing:4}} type="password" placeholder="••••••••"
              value={adminPw} onChange={e=>setAdminPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&adminLogin()} />
            {pwError&&<div style={{color:"#ef4444",fontSize:12,fontWeight:700,marginBottom:10}}>❌ Incorrect password</div>}
            <button style={{...C.greenBtn,width:"100%",padding:12}} onClick={adminLogin}>Login →</button>
            <button style={{...C.grayBtn,width:"100%",marginTop:8}} onClick={()=>setView("shop")}>← Back</button>
          </div>
        </div>
      )}

      {view==="admin" && adminAuth && adminView==="list" && (
        <div style={{padding:14}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
            <div style={{fontWeight:800,fontSize:16}}>📦 Stock Management</div>
            <button style={C.greenBtn} onClick={()=>setAdminView("addDrug")}>+ Add Medicine</button>
          </div>
          {drugs.map(drug=>(
            <div key={drug.id} style={C.adminCard}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                <div><div style={{fontWeight:800,fontSize:14}}>{drug.image} {drug.name}</div><div style={{fontSize:11,color:"#64748b"}}>{drug.category} · {drug.brands.length} brand{drug.brands.length!==1?"s":""}</div></div>
                <div style={{display:"flex",gap:6}}>
                  <button style={C.editBtn} onClick={()=>{setEditDrugId(drug.id);setAdminView("editDrug");}}>✏️ Edit</button>
                  <button style={C.redBtn} onClick={()=>deleteDrug(drug.id)}>🗑</button>
                </div>
              </div>
              {drug.brands.map((b,i)=>{const ss=stockStatus(b.stock);return(
                <div key={i} style={{display:"flex",alignItems:"center",gap:8,background:"#f8fafc",borderRadius:8,padding:"6px 10px",marginBottom:4}}>
                  <span style={{fontSize:12,fontWeight:700,flex:1}}>{b.name}</span>
                  {b.barcode&&<span style={{fontSize:9,color:"#94a3b8"}}>🔢{b.barcode.slice(-5)}</span>}
                  <span style={{...C.pill(ss),fontSize:10}}>{ss.label}</span>
                  <input style={C.stockInput} type="number" min="0" value={b.stock} onChange={e=>updateStock(drug.id,i,e.target.value)} />
                  <span style={{fontSize:11,color:"#94a3b8"}}>units</span>
                </div>
              );})}
            </div>
          ))}
          <button style={{...C.grayBtn,width:"100%",marginTop:8}} onClick={()=>{setAdminAuth(false);setView("shop");}}>🚪 Logout</button>
        </div>
      )}

      {view==="admin" && adminAuth && adminView==="addDrug" && (
        <div style={{padding:14}}>
          <button style={C.grayBtn} onClick={()=>setAdminView("list")}>← Back</button>
          <div style={{...C.section,marginTop:12}}>
            <div style={C.secTitle}>➕ New Medicine</div>
            <label style={C.inputLabel}>Medicine Name</label>
            <input style={C.inputField} placeholder="e.g. Paracetamol 500mg" value={newDrug.name} onChange={e=>setNewDrug(p=>({...p,name:e.target.value}))} />
            <label style={C.inputLabel}>Category</label>
            <select style={C.selectField} value={newDrug.category} onChange={e=>setNewDrug(p=>({...p,category:e.target.value}))}>
              {CATEGORY_OPTIONS.map(c=><option key={c}>{c}</option>)}
            </select>
            <label style={C.inputLabel}>Icon</label>
            <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap"}}>
              {["💊","🌿","💉","🩺","🧴","🩹"].map(em=>(
                <button key={em} style={{fontSize:24,background:newDrug.image===em?"#f0fdf4":"#f8fafc",border:newDrug.image===em?"2px solid #16a34a":"2px solid #e2e8f0",borderRadius:8,padding:"6px 10px",cursor:"pointer"}} onClick={()=>setNewDrug(p=>({...p,image:em}))}>{em}</button>
              ))}
            </div>
            <button style={{...C.greenBtn,width:"100%"}} onClick={saveDrug}>✅ Save Medicine</button>
          </div>
        </div>
      )}

      {view==="admin" && adminAuth && adminView==="editDrug" && editDrug && (
        <div style={{padding:14}}>
          <button style={C.grayBtn} onClick={()=>setAdminView("list")}>← Back</button>
          <div style={{...C.section,marginTop:12}}>
            <div style={C.secTitle}>{editDrug.image} {editDrug.name}</div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <div style={{fontWeight:700,fontSize:13}}>Brands</div>
              <button style={C.greenBtn} onClick={()=>{setNewBrand({name:"",stock:"",expiry:"",barcode:"",unitTypes:[{type:"Tablet",qty:1,price:""}]});setEditBrandIdx(null);setAdminView("editBrand");}}>+ Add Brand</button>
            </div>
            {editDrug.brands.length===0&&<div style={{color:"#94a3b8",fontSize:13,textAlign:"center",padding:12}}>No brands yet.</div>}
            {editDrug.brands.map((b,i)=>(
              <div key={i} style={{background:"#f8fafc",borderRadius:10,padding:12,marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                  <div><div style={{fontWeight:800,fontSize:13}}>{b.name}</div><div style={{fontSize:10,color:"#94a3b8"}}>Barcode: {b.barcode||"—"}</div><div style={{fontSize:11,color:expiryColor(b.expiry)}}>Exp: {b.expiry}</div></div>
                  <div style={{display:"flex",gap:6}}><button style={C.editBtn} onClick={()=>openEditBrand(editDrug.id,i)}>✏️</button><button style={C.redBtn} onClick={()=>deleteBrand(editDrug.id,i)}>🗑</button></div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <span style={C.pill(stockStatus(b.stock))}>{stockStatus(b.stock).label}</span>
                  <input style={C.stockInput} type="number" min="0" value={b.stock} onChange={e=>updateStock(editDrug.id,i,e.target.value)} />
                  <span style={{fontSize:11,color:"#64748b"}}>units</span>
                </div>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:6}}>
                  {b.unitTypes.map((u,j)=><span key={j} style={{fontSize:11,background:"#fff",border:"1px solid #e2e8f0",borderRadius:6,padding:"3px 8px",fontWeight:600}}>{u.type}: Rs.{u.price}</span>)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {view==="admin" && adminAuth && adminView==="editBrand" && (
        <div style={{padding:14}}>
          <button style={C.grayBtn} onClick={()=>setAdminView("editDrug")}>← Back</button>
          <div style={{...C.section,marginTop:12}}>
            <div style={C.secTitle}>{editBrandIdx!==null?"✏️ Brand Edit":"➕ New Brand"}</div>
            <label style={C.inputLabel}>Brand Name</label>
            <input style={C.inputField} placeholder="e.g. Panadol" value={newBrand.name} onChange={e=>setNewBrand(p=>({...p,name:e.target.value}))} />
            <label style={C.inputLabel}>Barcode (optional)</label>
            <input style={C.inputField} placeholder="e.g. 4012345678901" value={newBrand.barcode} onChange={e=>setNewBrand(p=>({...p,barcode:e.target.value}))} />
            <label style={C.inputLabel}>Stock (units)</label>
            <input style={C.inputField} type="number" placeholder="e.g. 100" value={newBrand.stock} onChange={e=>setNewBrand(p=>({...p,stock:e.target.value}))} />
            <label style={C.inputLabel}>Expiry Date</label>
            <input style={C.inputField} type="date" value={newBrand.expiry} onChange={e=>setNewBrand(p=>({...p,expiry:e.target.value}))} />
            <div style={{fontWeight:800,fontSize:13,color:"#16a34a",marginBottom:8}}>📦 Unit Types</div>
            {newBrand.unitTypes.map((u,i)=>(
              <div key={i} style={{background:"#f8fafc",borderRadius:10,padding:10,marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                  <span style={{fontWeight:700,fontSize:12,color:"#64748b"}}>Unit {i+1}</span>
                  {newBrand.unitTypes.length>1&&<button style={C.redBtn} onClick={()=>removeUnitType(i)}>🗑</button>}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                  <div><label style={C.inputLabel}>Type</label><select style={{...C.selectField,marginBottom:0}} value={u.type} onChange={e=>updateUT(i,"type",e.target.value)}>{UNIT_OPTIONS.map(o=><option key={o}>{o}</option>)}</select></div>
                  <div><label style={C.inputLabel}>Count</label><input style={{...C.inputField,marginBottom:0}} type="number" value={u.qty} onChange={e=>updateUT(i,"qty",e.target.value)} /></div>
                  <div><label style={C.inputLabel}>Price</label><input style={{...C.inputField,marginBottom:0}} type="number" value={u.price} onChange={e=>updateUT(i,"price",e.target.value)} /></div>
                </div>
              </div>
            ))}
            <button style={{...C.grayBtn,width:"100%",marginBottom:10}} onClick={addUnitType}>+ Add Unit Type</button>
            <button style={{...C.greenBtn,width:"100%"}} onClick={saveBrand}>✅ Save Brand</button>
          </div>
        </div>
      )}
    </div>
  );
}
