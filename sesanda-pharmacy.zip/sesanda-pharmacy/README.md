# Sesanda Pharmacy App

## Deploy to Vercel (Free)

1. Go to https://github.com and create a free account
2. Create a new repository called "sesanda-pharmacy"
3. Upload all these files
4. Go to https://vercel.com → Sign in with GitHub
5. Click "Add New Project" → Select "sesanda-pharmacy"
6. Click Deploy → Done!

Your app will be live at: https://sesanda-pharmacy.vercel.app

## Admin Login
Password: Madu
